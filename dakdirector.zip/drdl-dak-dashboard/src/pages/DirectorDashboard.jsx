import React, { useEffect, useState } from 'react';
import { Button, Tabs, Layout, Typography, message, Row, Col, Card, Space } from 'antd';
import { PlusOutlined, UserOutlined, FileTextOutlined, CheckCircleOutlined, ClockCircleOutlined } from '@ant-design/icons';
import { fetchDaks } from '../api/dakApi';
import DakTable from '../components/DakTable';
import DakFormModal from '../components/DakFormModal';

const { Content, Header } = Layout;
const { Title, Text } = Typography;

export default function DirectorDashboard() {
  const [daks, setDaks] = useState([]);
  const [activeTab, setActiveTab] = useState('All');
  const [showModal, setShowModal] = useState(false);

  const getDaks = async () => {
    try {
      const res = await fetchDaks();
      setDaks(res.data.filter(dak => !dak.DELETE_FLAG));
    } catch {
      message.error('Failed to fetch DAKs!');
    }
  };

  useEffect(() => { getDaks(); }, []);

  const filteredDaks = daks.filter(dak =>
    activeTab === 'All' ? true : dak.STATUS === activeTab
  );

  const stats = {
    total: daks.length,
    pending: daks.filter(dak => dak.STATUS === 'Pending').length,
    completed: daks.filter(dak => dak.STATUS === 'Completed').length
  };

  return (
    <Layout style={{ minHeight: '100vh', background: '#f0f2f5' }}>
      <Header
        style={{
          background: '#001529',
          color: '#fff',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          padding: '0 24px'
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <UserOutlined style={{ fontSize: 28, color: '#1890ff' }} />
          <Title level={3} style={{ color: '#fff', margin: 0 }}>
            DRDL Director Dashboard
          </Title>
        </div>
        <Button type="primary" icon={<PlusOutlined />} onClick={() => setShowModal(true)}>
          Add New DAK
        </Button>
      </Header>

      <Content style={{ margin: 24 }}>
        <Row gutter={[24, 24]}>
          <Col xs={24} sm={8}>
            <Card hoverable bordered={false} style={{ borderRadius: 8, boxShadow: '0 2px 8px rgba(0,0,0,0.1)' }}>
              <Space align="center">
                <FileTextOutlined style={{ fontSize: 28, color: '#13c2c2' }} />
                <div>
                  <Text type="secondary">Total DAKs</Text>
                  <Title level={3} style={{ margin: 0 }}>{stats.total}</Title>
                </div>
              </Space>
            </Card>
          </Col>
          <Col xs={24} sm={8}>
            <Card hoverable bordered={false} style={{ borderRadius: 8, boxShadow: '0 2px 8px rgba(0,0,0,0.1)' }}>
              <Space align="center">
                <ClockCircleOutlined style={{ fontSize: 28, color: '#faad14' }} />
                <div>
                  <Text type="secondary">Pending DAKs</Text>
                  <Title level={3} style={{ margin: 0 }}>{stats.pending}</Title>
                </div>
              </Space>
            </Card>
          </Col>
          <Col xs={24} sm={8}>
            <Card hoverable bordered={false} style={{ borderRadius: 8, boxShadow: '0 2px 8px rgba(0,0,0,0.1)' }}>
              <Space align="center">
                <CheckCircleOutlined style={{ fontSize: 28, color: '#52c41a' }} />
                <div>
                  <Text type="secondary">Completed DAKs</Text>
                  <Title level={3} style={{ margin: 0 }}>{stats.completed}</Title>
                </div>
              </Space>
            </Card>
          </Col>
        </Row>

        <div style={{ marginTop: 24 }}>
          <Tabs
            defaultActiveKey="All"
            activeKey={activeTab}
            onChange={setActiveTab}
            items={[
              { label: 'All', key: 'All' },
              { label: 'Pending', key: 'Pending' },
              { label: 'Completed', key: 'Completed' }
            ]}
          />
          <DakTable daks={filteredDaks} refreshDaks={getDaks} />
        </div>
      </Content>

      <DakFormModal open={showModal} closeModal={() => { setShowModal(false); getDaks(); }} />
    </Layout>
  );
}
