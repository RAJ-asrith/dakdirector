import 'antd/dist/reset.css';
import DirectorDashboard from "./pages/DirectorDashboard";
export default DirectorDashboard;
