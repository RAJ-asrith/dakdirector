import React, { useState } from 'react';
import { Table, Tag, Popconfirm, message, Tooltip, Button } from 'antd';
import { EditOutlined, DeleteOutlined } from '@ant-design/icons';
import { deleteDak } from '../api/dakApi';
import DakFormModal from './DakFormModal';

export default function DakTable({ daks, refreshDaks }) {
  const [editDak, setEditDak] = useState(null);

  const columns = [
    {
      title: 'DAK No',
      dataIndex: 'DAK_NO',
      key: 'DAK_NO',
      sorter: (a, b) => a.DAK_NO?.localeCompare(b.DAK_NO),
      responsive: ['xs', 'sm', 'md', 'lg', 'xl'],
    },
    {
      title: 'Status',
      dataIndex: 'STATUS',
      key: 'STATUS',
      filters: [
        { text: 'Pending', value: 'pending' },
        { text: 'Completed', value: 'completed' },
      ],
      onFilter: (value, record) =>
        record.STATUS?.toLowerCase() === value.trim(),
      render: status => (
        <Tag color={status?.toLowerCase() === 'completed' ? 'green' : 'orange'} key={status}>
          {status?.charAt(0).toUpperCase() + status?.slice(1)}
        </Tag>
      ),
      responsive: ['sm', 'md', 'lg', 'xl'],
    },
    {
      title: 'Org. of Corrsp.',
      dataIndex: 'ORG_OF_CORSP',
      key: 'ORG_OF_CORSP',
      responsive: ['md', 'lg', 'xl'],
    },
    {
      title: 'Nomenclature',
      dataIndex: 'NOMENCLATURE',
      key: 'NOMENCLATURE',
      responsive: ['lg', 'xl'],
    },
    {
      title: 'Date of Comp.',
      dataIndex: 'DATE_OF_COMP',
      key: 'DATE_OF_COMP',
      responsive: ['lg', 'xl'],
      sorter: (a, b) => new Date(a.DATE_OF_COMP) - new Date(b.DATE_OF_COMP),
    },
    {
      title: 'Actions',
      key: 'actions',
      fixed: 'right',
      render: (_, record) => (
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            background: '#f5f7fa',
            borderRadius: 8,
            gap: 8,
            padding: '4px 10px'
          }}
        >
          <Tooltip title="Edit">
            <Button
              type="text"
              shape="circle"
              icon={<EditOutlined style={{ color: '#1890ff' }} />}
              onClick={() => setEditDak(record)}
              aria-label="Edit"
            />
          </Tooltip>
          <Popconfirm
            title="Are you sure to delete this DAK?"
            placement="top"
            onConfirm={async () => {
              try {
                await deleteDak(record.id);
                refreshDaks();
                message.success('Deleted');
              } catch {
                message.error('Delete failed');
              }
            }}
            okText="Yes"
            cancelText="No"
          >
            <Tooltip title="Delete">
              <Button
                type="text"
                shape="circle"
                icon={<DeleteOutlined style={{ color: '#ff4d4f' }} />}
                aria-label="Delete"
              />
            </Tooltip>
          </Popconfirm>
        </div>
      ),
      responsive: ['xs', 'sm', 'md', 'lg', 'xl'],
    },
  ];

  return (
    <>
      <Table
        columns={columns}
        dataSource={daks}
        rowKey="id"
        pagination={{ pageSize: 10 }}
        scroll={{ x: 800 }}
      />
      {editDak && (
        <DakFormModal
          open={!!editDak}
          initialValues={editDak}
          isUpdate={true}
          closeModal={() => {
            setEditDak(null);
            refreshDaks();
          }}
        />
      )}
    </>
  );
}
