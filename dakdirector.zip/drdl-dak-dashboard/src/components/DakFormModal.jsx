import React, { useEffect, useState } from 'react';
import {
  Modal,
  Form,
  Input,
  DatePicker,
  message,
  Button,
  Spin,
  Upload,
  notification,
  Select,
  Space
} from 'antd';
import {
  UploadOutlined,
  FileTextOutlined,
  CalendarOutlined,
  UserOutlined,
  TeamOutlined
} from '@ant-design/icons';
import dayjs from 'dayjs';
import axios from 'axios';
import { createDak, updateDak, fetchDaks } from '../api/dakApi';


function transformInitialValues(initialValues) {
  if (!initialValues) return {};
  const dateFields = ['EC_DATE', 'DATE_OF_COMP'];
  const result = { ...initialValues };
  dateFields.forEach(field => {
    if (result[field]) result[field] = dayjs(result[field]);
  });
  return result;
}


export default function DakFormModal({ open, closeModal, initialValues, isUpdate }) {
  const [form] = Form.useForm();
  const [loading, setLoading] = useState(false);
  const [fileUrl, setFileUrl] = useState('');
  const [uploading, setUploading] = useState(false);
  const [scientists, setScientists] = useState([]);


  // ⚡ Entry mode: 'manual' or 'dakTable' (default manual)
  const [entryMode, setEntryMode] = useState('manual');
  const [nomenData, setNomenData] = useState([]);
  const [selectedNomenclature, setSelectedNomenclature] = useState(''); // For read-only nomenclature in dakTable mode
  // ⚡ ADDED: State to lock/unlock fields until a mode is chosen
  const [isModeSelected, setIsModeSelected] = useState(false);


  useEffect(() => {
    if (open) {
      axios
        .get('https://687b3ad3b4bc7cfbda850ef2.mockapi.io/scientist')
        .then(res => setScientists(res.data))
        .catch(() => setScientists([]));
    }
  }, [open]);


  useEffect(() => {
    // Fetch nominclature data only if modal is open and mode is dakTable
    if (open && entryMode === 'dakTable') {
      axios
        .get('https://6883210821fa24876a9cc49e.mockapi.io/nomen')
        .then(res => setNomenData(res.data))
        .catch(() => {
          setNomenData([]);
          message.error('Failed to fetch nomenclature data.');
        });
    }
    if (entryMode === 'manual') {
      setNomenData([]);
      setSelectedNomenclature('');
      // Only reset values if a mode has been selected, to avoid wiping initial DAK no.
      if (isModeSelected) {
        form.setFieldsValue({ ORG_OF_CORSP: '', NOMENCLATURE: '' });
      }
    }
  }, [open, entryMode, form, isModeSelected]);


  const selectedResp = Form.useWatch('RESP_OFFICER', form) || null;
  const selectedCoord = Form.useWatch('CO_ORD', form) || null;
  const selectedMonitors = Form.useWatch('MONITORING_OFFICERS', form) || [];


  // ⚡ UPDATED: When user selects an origin from nomenclature dropdown:
  const onOriginSelect = id => {
    const selected = nomenData.find(item => item.id === id);
    if (selected) {
      form.setFieldsValue({
        ORG_OF_CORSP: selected.origin,
        NOMENCLATURE: selected.nomenclature,
        // ⚡ FIXED: Parse date string directly, not as UNIX timestamp
        EC_DATE: dayjs(selected.date) 
      });
      setSelectedNomenclature(selected.nomenclature);
    } else {
      // Clear values when deselected
      form.setFieldsValue({
        ORG_OF_CORSP: '',
        NOMENCLATURE: '',
        EC_DATE: null
      });
      setSelectedNomenclature('');
    }
  };


  const generateDAKNo = async () => {
    const todayObj = dayjs();
    const daknoPrefix = todayObj.format('YYMMDD');
    setLoading(true);
    let todayCount = 0;
    try {
      const res = await fetchDaks();
      todayCount = res.data.filter(
        dak => dak.DAK_NO && dak.DAK_NO.startsWith(daknoPrefix)
      ).length;
    } catch {} 
    setLoading(false);
    return `${daknoPrefix}${todayCount + 1}`;
  };


  // ⚡ UPDATED: This effect now handles locking/unlocking fields
  useEffect(() => {
    if (open) {
      if (isUpdate && initialValues) {
        form.setFieldsValue(transformInitialValues(initialValues));
        setFileUrl(initialValues.DAK_ATTACHEMENT || '');
        setEntryMode('manual');
        setSelectedNomenclature('');
        setIsModeSelected(true); // Fields are unlocked when updating
      } else {
        generateDAKNo().then(num => {
          const today = dayjs();
          form.setFieldsValue({ EC_DATE: today, DAK_NO: num });
          setEntryMode('manual');
          setSelectedNomenclature('');
          setIsModeSelected(false); // Fields are locked for new entries
        });
        setFileUrl('');
      }
    } else {
      form.resetFields();
      setFileUrl('');
      setLoading(false);
      setEntryMode('manual');
      setSelectedNomenclature('');
      setIsModeSelected(false);
    }
    // eslint-disable-next-line
  }, [open, initialValues, isUpdate]);


  const customFileUpload = file => {
    setUploading(true);
    setTimeout(() => {
      const fakeUrl = URL.createObjectURL(file);
      form.setFieldsValue({ DAK_ATTACHEMENT: fakeUrl });
      setFileUrl(fakeUrl);
      setUploading(false);
      notification.success({ message: 'File attached' });
    }, 1200);
    return false;
  };


  const handleFinish = async values => {
    const formatted = {
      ...values,
      EC_DATE: values.EC_DATE?.format('YYYY-MM-DD'),
      DATE_OF_COMP: values.DATE_OF_COMP?.format('YYYY-MM-DD'),
      DIRECTOR_REMARKS: values.DIRECTOR_REMARKS,
      MONITORING_OFFICERS: values.MONITORING_OFFICERS || [],
      DAK_NO: values.DAK_NO,
      DAK_ATTACHEMENT: values.DAK_ATTACHEMENT || fileUrl,
      DELETE_FLAG: false,
      STATUS: 'Pending',
      REC_DATE: ' ',
      ACT_DATE_OF_COMP: ' ',
      REMARKS: ' ',
      DAK_INT: ' ',
      MODE_OF_REPLY: ' ',
      RES_INT_DATE: ' ',
      RES_ATTACHEMENT: ' ',
      ION_LETTER_NO: ' ',
      ION_LETTER_DATE: ' ',
      DAK_ENTRY_DATE: dayjs().format('YYYY-MM-DD')
    };
    try {
      if (isUpdate && initialValues?.id) {
        await updateDak(initialValues.id, { ...formatted, DAK_NO: initialValues.DAK_NO });
        message.success('DAK updated successfully');
      } else {
        await createDak(formatted);
        message.success('DAK created successfully');
      }
      form.resetFields();
      closeModal();
      setEntryMode('manual');
      setSelectedNomenclature('');
    } catch {
      message.error('Failed to submit DAK');
    }
  };


  function getFilteredScientistOptions(excludeList = []) {
    return scientists
      .filter(sc => !excludeList.includes(sc.name))
      .map(sc => ({
        label: sc.name + (sc.designation ? ` (${sc.designation})` : ''),
        value: sc.name
      }));
  }


  // === Styles (kept unchanged from your original code) ===
  const modalStyles = {
    top: 0,
    padding: 0,
    maxWidth: '100vw'
  };
  const modalBodyStyles = {
    minHeight: '100vh',
    overflow: 'auto',
    padding: 0,
    background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
    borderRadius: 0,
    boxSizing: 'border-box',
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'center'
  };
  const formContainerStyles = {
    background: 'rgba(255, 255, 255, 0.95)',
    backdropFilter: 'blur(20px)',
    borderRadius: '20px',
    padding: '60px',
    margin: '40px',
    width: 'calc(100% - 80px)',
    maxWidth: 'none',
    minHeight: 'calc(100vh - 80px)',
    boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)',
    border: '1px solid rgba(255, 255, 255, 0.2)',
    position: 'relative',
    overflow: 'hidden',
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'center'
  };
  const formContainerBeforeStyles = {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: '4px',
    background:
      'linear-gradient(90deg, #667eea, #764ba2, #f093fb, #f5576c)',
    backgroundSize: '400% 400%',
    zIndex: 1
  };
  const labelStyles = {
    color: '#374151',
    fontWeight: '600',
    fontSize: '15px',
    marginBottom: '8px',
    display: 'flex',
    alignItems: 'center',
    gap: '8px'
  };
  const inputStyles = {
    borderRadius: '12px',
    border: '2px solid #e5e7eb',
    padding: '12px 16px',
    fontSize: '15px',
    transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
    boxShadow: '0 1px 3px 0 rgba(0, 0, 0, 0.1)',
    background: 'rgba(255, 255, 255, 0.9)',
    backdropFilter: 'blur(10px)'
  };
  const readOnlyInputStyles = {
    ...inputStyles,
    background:
      'linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%)',
    color: '#1e293b',
    fontWeight: '700',
    letterSpacing: '2px',
    textAlign: 'center',
    fontFamily: 'Courier New, monospace',
    border: '2px solid #cbd5e1'
  };
  const primaryButtonStyles = {
    borderRadius: '12px',
    fontWeight: '600',
    fontSize: '15px',
    height: '48px',
    padding: '0 32px',
    transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
    border: 'none',
    background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
    boxShadow: '0 4px 15px 0 rgba(102, 126, 234, 0.4)'
  };
  const secondaryButtonStyles = {
    borderRadius: '12px',
    fontWeight: '600',
    fontSize: '15px',
    height: '48px',
    padding: '0 32px',
    transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
    background: 'rgba(255, 255, 255, 0.9)',
    color: '#6b7280',
    border: '2px solid #e5e7eb',
    backdropFilter: 'blur(10px)'
  };
  const uploadButtonStyles = {
    width: '100%',
    background:
      'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)',
    color: 'white',
    border: 'none',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: '8px',
    boxShadow: '0 4px 15px 0 rgba(245, 87, 108, 0.4)',
    borderRadius: '12px',
    fontWeight: '600',
    fontSize: '15px',
    height: '48px',
    padding: '0 32px',
    transition:
      'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)'
  };
  const filePreviewStyles = {
    marginTop: '12px',
    padding: '16px',
    background: 'rgba(102, 126, 234, 0.05)',
    border: '2px dashed rgba(102, 126, 234, 0.2)',
    borderRadius: '12px',
    display: 'flex',
    alignItems: 'center',
    gap: '12px',
    transition: 'all 0.3s ease'
  };
  const buttonGroupStyles = {
    display: 'flex',
    justifyContent: 'center',
    gap: '20px',
    marginTop: '40px',
    paddingTop: '32px',
    borderTop: '1px solid #e5e7eb'
  };
  const titleStyles = {
    color: 'white',
    fontSize: 28,
    fontWeight: 700,
    textAlign: 'center',
    textShadow: '0 2px 4px rgba(0, 0, 0, 0.3)',
    letterSpacing: '-0.5px'
  };



  return (
    <Modal
      open={open}
      title={<span style={titleStyles}>{isUpdate ? '✨ Update DAK' : ' Add New DAK'}</span>}
      onCancel={() => {
        form.resetFields();
        closeModal();
        setEntryMode('manual');
        setIsModeSelected(false);
      }}
      footer={null}
      maskClosable={false}
      width="100vw"
      style={modalStyles}
      styles={{
        body: modalBodyStyles,
        header: {
          background: 'rgba(255, 255, 255, 0.1)',
          backdropFilter: 'blur(20px)',
          border: 'none',
          borderBottom: '1px solid rgba(255, 255, 255, 0.1)',
          padding: '24px 32px'
        },
        content: {
          background: 'transparent',
          borderRadius: '24px',
          overflow: 'hidden',
          boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.25)',
          border: '1px solid rgba(255, 255, 255, 0.1)'
        }
      }}
      destroyOnHidden
    >
      <div style={formContainerStyles}>
        <div style={formContainerBeforeStyles}></div>
        <Spin spinning={loading || uploading}>
          <Form
            layout="vertical"
            form={form}
            onFinish={handleFinish}
            autoComplete="off"
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(400px, 1fr))',
              gap: '40px',
              alignItems: 'start'
            }}
          >
            {/* Date of Receipt */}
            <Form.Item
              name="EC_DATE"
              label={<span style={labelStyles}><CalendarOutlined />Date of Receipt</span>}
              rules={[{ required: true, message: 'Please select date of receipt' }]}
              style={{ marginBottom: '28px' }}
            >
              <DatePicker style={{ ...inputStyles, width: '100%' }} placeholder="Select receipt date" />
            </Form.Item>


            {/* DAK No */}
            <Form.Item
              name="DAK_NO"
              label={<span style={labelStyles}><FileTextOutlined />DAK No</span>}
              rules={[{ required: true }]}
              style={{ marginBottom: '28px' }}
            >
              <Input style={readOnlyInputStyles} readOnly />
            </Form.Item>


            {/* ⚡ Entry Mode buttons, visible only on add */}
            {!isUpdate && (
              <Form.Item style={{ gridColumn: '1 / -1', marginBottom: 0 }}>
                <Space>
                  <Button type={entryMode === 'manual' ? 'primary' : 'default'} onClick={() => { setEntryMode('manual'); setIsModeSelected(true); }}>
                    Manual Entry
                  </Button>
                  <Button type={entryMode === 'dakTable' ? 'primary' : 'default'} onClick={() => { setEntryMode('dakTable'); setIsModeSelected(true); }}>
                    From DAK Table
                  </Button>
                </Space>
              </Form.Item>
            )}


            {/* Origin of Correspondence: input or select */}
            <Form.Item
              name="ORG_OF_CORSP"
              label={<span style={labelStyles}><FileTextOutlined />Origin of Correspondence</span>}
              rules={[{ required: true }]}
              style={{ marginBottom: '28px' }}
            >
              {entryMode === 'manual' ? (
                <Input style={inputStyles} placeholder="Enter the origin of correspondence" disabled={!isModeSelected && !isUpdate} />
              ) : (
                <Select
                  placeholder="Select Origin of Correspondence"
                  showSearch
                  optionFilterProp="children"
                  onChange={onOriginSelect}
                  filterOption={(input, option) =>
                    option?.children.toLowerCase().includes(input.toLowerCase())
                  }
                  allowClear
                  disabled={!isModeSelected && !isUpdate}
                  notFoundContent={loading ? <Spin size="small" /> : null}
                >
                  {nomenData.map(item => (
                    <Select.Option key={item.id} value={item.id}>
                      {item.origin}
                    </Select.Option>
                  ))}
                </Select>
              )}
            </Form.Item>


            {/* Nomenclature: input or readonly input */}
            <Form.Item
              name="NOMENCLATURE"
              label={<span style={labelStyles}><FileTextOutlined />Nomenclature</span>}
              rules={[{ required: true }]}
              style={{ marginBottom: '28px' }}
            >
              {entryMode === 'manual' ? (
                <Input style={inputStyles} placeholder="Enter nomenclature" disabled={!isModeSelected && !isUpdate} />
              ) : (
                <Input
                  style={{ ...inputStyles, backgroundColor: '#f0f0f0', cursor: 'not-allowed' }}
                  readOnly
                  disabled={!isModeSelected && !isUpdate}
                  value={selectedNomenclature}
                />
              )}
            </Form.Item>


            {/* Rest of your form fields remain unchanged, copied directly from your original code */}


            {/* ...RESP_OFFICER, CO_ORD, DATE_OF_COMP, DIRECTOR_REMARKS, MONITORING_OFFICERS, DAK_ATTACHEMENT, action buttons, etc... */}


            {/* Responsible Officer */}
            <Form.Item
              name="RESP_OFFICER"
              label={<span style={labelStyles}><UserOutlined />Responsible Officer</span>}
              rules={[{ required: true, message: "Please select Responsible Officer" }]}
              style={{ marginBottom: '28px' }}
            >
              <Select
                showSearch
                allowClear
                placeholder="Select a responsible officer"
                options={getFilteredScientistOptions([selectedCoord, ...(selectedMonitors || [])].filter(Boolean))}
                filterOption={(input, option) =>
                  option?.label?.toLowerCase().includes(input.toLowerCase())
                }
                style={{ ...inputStyles, padding: 0 }}
              />
            </Form.Item>


            {/* Coordinator */}
            <Form.Item
              name="CO_ORD"
              label={<span style={labelStyles}><UserOutlined />Coordinator</span>}
              rules={[{ required: true, message: "Please select a Coordinator" }]}
              style={{ marginBottom: '28px' }}
            >
              <Select
                showSearch
                allowClear
                placeholder="Select a coordinator"
                options={getFilteredScientistOptions([selectedResp, ...(selectedMonitors || [])].filter(Boolean))}
                filterOption={(input, option) =>
                  option?.label?.toLowerCase().includes(input.toLowerCase())
                }
                style={{ ...inputStyles, padding: 0 }}
              />
            </Form.Item>


            {/* Probable Date of Completion */}
            <Form.Item
              name="DATE_OF_COMP"
              label={<span style={labelStyles}><CalendarOutlined />Probable Date of Completion</span>}
              rules={[{ required: true, message: 'Please select the probable date of completion' }]}
              style={{ marginBottom: '28px' }}
            >
              <DatePicker
                style={{ ...inputStyles, width: '100%' }}
                placeholder="Select completion date"
                disabledDate={date => {
                  const ecDate = form.getFieldValue('EC_DATE');
                  if (!ecDate) return false;
                  return date.isBefore(dayjs(ecDate), 'day');
                }}
              />
            </Form.Item>


            {/* Director Remarks */}
            <Form.Item
              name="DIRECTOR_REMARKS"
              label={<span style={labelStyles}><FileTextOutlined />Director Remarks</span>}
              style={{ marginBottom: '28px' }}
            >
              <Input.TextArea
                rows={3}
                placeholder="Enter director remarks..."
                style={inputStyles}
              />
            </Form.Item>


            {/* Other Responsible Officers */}
            <Form.Item
              name="MONITORING_OFFICERS"
              label={<span style={labelStyles}><TeamOutlined />Other Responsible Officers</span>}
              style={{ marginBottom: '28px' }}
            >
              <Select
                mode="multiple"
                showSearch
                allowClear
                placeholder="Select additional officers"
                options={getFilteredScientistOptions([selectedResp, selectedCoord].filter(Boolean))}
                filterOption={(input, option) =>
                  option?.label?.toLowerCase().includes(input.toLowerCase())
                }
                style={{ ...inputStyles, padding: 0 }}
              />
            </Form.Item>


            {/* Attachment by Director */}
            <Form.Item
              name="DAK_ATTACHEMENT"
              label={<span style={labelStyles}><UploadOutlined />Attachment by Director</span>}
              style={{ marginBottom: '28px' }}
            >
              <Upload
                customRequest={({ file }) => customFileUpload(file)}
                showUploadList={false}
                accept=".pdf,.jpg,.png,.docx"
                style={{ width: '100%' }}
              >
                <Button style={uploadButtonStyles}>
                  <UploadOutlined />
                  Choose File to Attach
                </Button>
              </Upload>
              {fileUrl && (
                <div style={filePreviewStyles}>
                  <FileTextOutlined style={{ color: '#667eea', fontSize: '18px' }} />
                  <a
                    href={fileUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    style={{ color: '#667eea', textDecoration: 'none', fontWeight: '600', display: 'flex', alignItems: 'center', gap: '8px' }}
                  >
                    <FileTextOutlined />
                    View Attached File
                  </a>
                </div>
              )}
            </Form.Item>


            {/* Submit / Cancel buttons */}
            <div style={{ gridColumn: '1 / -1' }}>
              <div style={buttonGroupStyles}>
                <Button
                  size="large"
                  onClick={() => {
                    form.resetFields();
                    closeModal();
                    setEntryMode('manual');
                    setIsModeSelected(false);
                  }}
                  style={secondaryButtonStyles}
                >
                  Cancel
                </Button>
                <Button
                  type="primary"
                  size="large"
                  htmlType="submit"
                  style={primaryButtonStyles}
                >
                  {isUpdate ? ' Update DAK' : ' Submit DAK'}
                </Button>
              </div>
            </div>
          </Form>
        </Spin>
      </div>
    </Modal>
  );
}