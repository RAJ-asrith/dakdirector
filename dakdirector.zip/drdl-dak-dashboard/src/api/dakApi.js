import axios from 'axios';

const API_URL = 'https://687b3ad3b4bc7cfbda850ef2.mockapi.io/dak'; // Replace with your actual MockAPI URL

export const fetchDaks = () => axios.get(API_URL);
export const fetchDakById = (id) => axios.get(`${API_URL}/${id}`);
export const createDak = (data) => axios.post(API_URL, data);
export const updateDak = (id, data) => axios.put(`${API_URL}/${id}`, data);
export const deleteDak = (id) => axios.delete(`${API_URL}/${id}`);
